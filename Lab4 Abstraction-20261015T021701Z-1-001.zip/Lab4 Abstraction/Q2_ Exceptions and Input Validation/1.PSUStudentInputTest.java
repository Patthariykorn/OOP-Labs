
import java.util.Scanner;

public class PSUStudentInputTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter age: ");
            int age = input.nextInt();

            System.out.print("Enter GPA: ");
            double gpa = input.nextDouble();

            UndergradStudent undergrad =
                new UndergradStudent(age, gpa);

            GradStudent grad =
                new GradStudent(age, gpa);

            System.out.println("UndergradStudent created.");
            System.out.println("GradStudent created.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (java.util.InputMismatchException e) {
            System.out.println("Error: Please enter valid numbers.");
        } finally {
            input.close();
        }
    }
}
